
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '1.2.0'
version = '1.2.0'
full_version = '1.2.0'
git_revision = '722bfc3f2cb4884c7ef3eb87cefcb91ff7479208'
release = True

if not release:
    version = full_version
